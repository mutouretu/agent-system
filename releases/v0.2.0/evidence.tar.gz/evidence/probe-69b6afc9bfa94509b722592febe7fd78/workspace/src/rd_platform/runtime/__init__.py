"""Docker-only execution runtime."""
